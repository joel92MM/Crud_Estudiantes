package com.servicios.estudiantes.app.dominio.excepciones;

public class EstudianteNotFoundExcepcion extends RuntimeException{
}
